################################################################################
#                              JOGO DA MEMÓRIA                                 #
#                              Versão 0.8 beta                                 #
################################################################################


#importar bibliotecas

from tkinter import *
import winsound
import random
import time


#FUNÇÕES:

#reiniciar o jogo

def reiniciar():

    global pares, vencedor, lista_btn
    vencedor = 0

    pares = [maca, maca, banana, banana, cereja, cereja, limao, limao, laranja, laranja, pera, pera, ananas, ananas, morango, morango]
    random.shuffle(pares)

    legenda.config(text='', bg='light blue',)
    for btn in lista_btn:
        btn.config(image= inicio, state='normal')
    janela.config(bg='light blue')


#jogo concluído

def vitoria():
    
    legenda.config(text='PARABÉNS!!!', bg= 'orange',)        
    janela.config(bg='orange')
    janela.update()
    winsound.PlaySound('vitoria.wav', winsound.SND_FILENAME)


#verificar emparelhamento ao clicar nos botões

def click_botao(b, num):

    global cont, lista_resp, dict_resp, vencedor, lista_certo, lista_errado

    if num not in lista_resp:

        if cont < 2:
            b['image'] = pares[num] 
            lista_resp.append(num)
            dict_resp[b] = pares[num]
            cont += 1
        
        if len(lista_resp) == 2:
            if pares[lista_resp[0]] == pares[lista_resp[1]]:  
                legenda.config(text=lista_certo[random.randint(0,3)])
                for chave in dict_resp:
                    chave['state'] = 'disable'
                janela.update()
                winsound.PlaySound('certo.wav', winsound.SND_FILENAME)    
                cont = 0
                lista_resp = []
                dict_resp = {}
                vencedor += 1
                if vencedor == 8:
                    vitoria()    
                else:
                    legenda.config(text='')
            else:  
                cont = 0
                lista_resp = []
                legenda.config(text=lista_errado[random.randint(0,3)])
                janela.update()
                time.sleep(0.5)
                winsound.PlaySound('errado.wav', winsound.SND_FILENAME)     
                legenda.config(text='')
                for chave in dict_resp:
                    chave['image'] = inicio
                dict_resp = {}    


#centrar janela

def centrar (jan):

    ecra_l = jan.winfo_screenwidth()
    ecra_a = jan.winfo_screenheight()
    jan_l = 600
    jan_a = 630
    posx = ecra_l//2 - jan_l//2
    posy = ecra_a//2 - jan_a//2
    jan.geometry(f'{jan_l}x{jan_a}+{posx}+{posy}')


#PROGRAMA PRINCIPAL:

#criar janela do jogo

janela = Tk()
centrar(janela)
janela.title('Jogo da Memória')
janela.iconbitmap('omega3344.ico')
janela.config(bg='light blue')
janela.resizable(0,0)


#criar frame

frame = Frame(janela)
frame.pack(pady=10)


#definição de variáveis

vencedor = 0
cont = 0
lista_resp = []
dict_resp = {}


#importarção de imagens

maca = PhotoImage(file = 'maca.png').subsample(3,3)
banana = PhotoImage(file = 'banana.png').subsample(3,3)
cereja = PhotoImage(file = 'cereja.png').subsample(3,3)
limao = PhotoImage(file = 'limao.png').subsample(3,3)
laranja = PhotoImage(file = 'laranja.png').subsample(3,3)
pera = PhotoImage(file = 'pera.png').subsample(3,3)
ananas = PhotoImage(file = 'ananas.png').subsample(3,3)
morango = PhotoImage(file = 'morango.png').subsample(3,3)
inicio = PhotoImage(file = 'inicio.png').subsample(3,3)


#criar emparelhamento e baralhar imagens

pares = [maca, maca, banana, banana, cereja, cereja, limao, limao, laranja, laranja, pera, pera, ananas, ananas, morango, morango]
random.shuffle(pares)


#criar botões com imagem inicial

b0 = Button(frame, image=inicio, command=lambda: click_botao(b0, 0), relief='groove')
b1 = Button(frame, image=inicio, command=lambda: click_botao(b1, 1), relief='groove')
b2 = Button(frame, image=inicio, command=lambda: click_botao(b2, 2), relief='groove')
b3 = Button(frame, image=inicio, command=lambda: click_botao(b3, 3), relief='groove')
b4 = Button(frame, image=inicio, command=lambda: click_botao(b4, 4), relief='groove')
b5 = Button(frame, image=inicio, command=lambda: click_botao(b5, 5), relief='groove')
b6 = Button(frame, image=inicio, command=lambda: click_botao(b6, 6), relief='groove')
b7 = Button(frame, image=inicio, command=lambda: click_botao(b7, 7), relief='groove')
b8 = Button(frame, image=inicio, command=lambda: click_botao(b8, 8), relief='groove')
b9 = Button(frame, image=inicio, command=lambda: click_botao(b9, 9), relief='groove')
b10 = Button(frame, image=inicio, command=lambda: click_botao(b10, 10), relief='groove')
b11 = Button(frame, image=inicio, command=lambda: click_botao(b11, 11), relief='groove')
b12 = Button(frame, image=inicio, command=lambda: click_botao(b12, 12), relief='groove')
b13 = Button(frame, image=inicio, command=lambda: click_botao(b13, 13), relief='groove')
b14 = Button(frame, image=inicio, command=lambda: click_botao(b14, 14), relief='groove')
b15 = Button(frame, image=inicio, command=lambda: click_botao(b15, 15), relief='groove')


#dispor botões em grid

lista_btn = [b0,b1,b2,b3,b4,b5,b6,b7,b8,b9,b10,b11,b12,b13,b14,b15]

for y in range(4):
    for x in range(4):
        lista_btn[4*y+x].grid(row=y, column=x)


#criar label para mensagem de texto

legenda = Label(janela, text='', bg='light blue', font= ('Helvetica', 20, 'bold'))
legenda.pack(pady=20)


#criar listas de mensagens de texto

lista_certo = ['Certíssimo!','És o maior!','Bem jogado!','Craque!']
lista_errado = ['Incorreto!','Tenta novamente!','Podes fazer melhor!','Não estás atento!']


#criar menu de opções

menu = Menu(janela)
janela.config(menu=menu)

opcoes_menu = Menu(menu, tearoff=False)
menu.add_cascade(label='Opções do jogo', menu=opcoes_menu)
opcoes_menu.add_command(label='Reiniciar jogo', command=reiniciar)
opcoes_menu.add_separator()
opcoes_menu.add_command(label='Sair do jogo', command=janela.destroy)


#mensagem copyright

icon = PhotoImage(file = 'omega_icon.png').subsample(30,30)
Label(janela, image=icon, text='\u00A9 2022 - Fernando Cunha  ', font= ('Helvetica', 7), bg='black', fg='white', compound=LEFT).pack(anchor=SE)


#manter janela ativa

janela.mainloop()


################################################################################
#                         © 2022 - Fernando Cunha                              #
################################################################################